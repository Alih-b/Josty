from __future__ import annotations

import asyncio
import ipaddress
import re
import socket
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, datetime
from typing import Any, Literal
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

import httpx
from ddgs import DDGS

SearchMode = Literal["plain", "exact", "oss"]
SearchCategory = Literal["text", "news"]
SafeSearch = Literal["on", "moderate", "off"]
TimeLimit = Literal["d", "w", "m", "y"]

SCHEMA_VERSION = "1.0"
MAX_SITES = 5
TRACKING_QUERY_KEYS = {
    "dclid",
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid",
    "msclkid",
}


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str = ""
    sources: list[str] = field(default_factory=list)
    published_at: str | None = None
    publisher: str | None = None
    score: float = 0.0
    content: str | None = None
    extraction_method: str | None = None
    fetched_url: str | None = None
    fetched_at: str | None = None
    fetch_error: str | None = None

    def dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ProviderStatus:
    provider: str
    query: str
    ok: bool
    result_count: int = 0
    error: str | None = None

    def dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SearchRun:
    query: str
    results: list[SearchResult] = field(default_factory=list)
    providers: list[ProviderStatus] = field(default_factory=list)

    @property
    def partial(self) -> bool:
        return any(not provider.ok for provider in self.providers)

    @property
    def status(self) -> str:
        if not self.results and self.providers and all(not item.ok for item in self.providers):
            return "failed"
        if self.partial:
            return "degraded"
        return "complete"

    def dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "query": self.query,
            "status": self.status,
            "count": len(self.results),
            "partial": self.partial,
            "providers": [provider.dict() for provider in self.providers],
            "results": [result.dict() for result in self.results],
        }


def canonical(url: str) -> str:
    """Normalize URL variants while preserving resource-identifying query parameters."""
    parsed = urlsplit(url.strip())
    scheme = parsed.scheme.lower()
    hostname = (parsed.hostname or "").lower()
    if scheme not in ("http", "https") or not hostname or parsed.username or parsed.password:
        raise ValueError("canonical URLs must be public-style HTTP(S) URLs")
    port = parsed.port
    hostname = f"[{hostname}]" if ":" in hostname else hostname
    if port and not ((scheme == "http" and port == 80) or (scheme == "https" and port == 443)):
        hostname = f"{hostname}:{port}"
    path = parsed.path.rstrip("/") or "/"
    query = urlencode(
        [
            (key, value)
            for key, value in parse_qsl(parsed.query, keep_blank_values=True)
            if not key.lower().startswith("utm_") and key.lower() not in TRACKING_QUERY_KEYS
        ],
        doseq=True,
    )
    return urlunsplit((scheme, hostname, path, query, ""))


def _clone(item: SearchResult) -> SearchResult:
    return replace(item, sources=list(item.sources))


def _merge_result(current: SearchResult, candidate: SearchResult) -> None:
    current.sources = list(dict.fromkeys([*current.sources, *candidate.sources]))
    if len(candidate.snippet) > len(current.snippet):
        current.snippet = candidate.snippet
        current.title = candidate.title or current.title
    current.published_at = current.published_at or candidate.published_at
    current.publisher = current.publisher or candidate.publisher


def rrf(ranked: list[list[SearchResult]], k: int = 60) -> list[SearchResult]:
    """Fuse independent ranked lists with Reciprocal Rank Fusion."""
    if k < 1:
        raise ValueError("k must be positive")
    merged: dict[str, SearchResult] = {}
    scores: dict[str, float] = {}
    for results in ranked:
        seen_in_list: set[str] = set()
        for rank, item in enumerate(results, 1):
            try:
                key = canonical(item.url)
            except ValueError:
                continue
            if not key or key in seen_in_list:
                continue
            seen_in_list.add(key)
            scores[key] = scores.get(key, 0.0) + 1 / (k + rank)
            if key not in merged:
                merged[key] = _clone(item)
            else:
                _merge_result(merged[key], item)
    for key, item in merged.items():
        item.score = round(scores[key], 6)
    return sorted(
        merged.values(),
        key=lambda item: (-item.score, canonical(item.url)),
    )


def merge_query_variants(ranked: list[list[SearchResult]]) -> list[SearchResult]:
    """Merge query rewrites for one backend without counting them as independent votes."""
    merged: dict[str, tuple[int, int, SearchResult]] = {}
    for variant_index, results in enumerate(ranked):
        for rank, item in enumerate(results, 1):
            try:
                key = canonical(item.url)
            except ValueError:
                continue
            current = merged.get(key)
            if current is None:
                merged[key] = (rank, variant_index, _clone(item))
                continue
            best_rank, best_variant, saved = current
            _merge_result(saved, item)
            merged[key] = (min(rank, best_rank), min(variant_index, best_variant), saved)
    return [
        item
        for _, _, item in sorted(
            merged.values(),
            key=lambda row: (row[0], row[1], canonical(row[2].url)),
        )
    ]


def normalize_sites(sites: list[str] | None) -> list[str]:
    if not sites:
        return []
    if len(sites) > MAX_SITES:
        raise ValueError(f"at most {MAX_SITES} site filters are allowed")
    normalized: list[str] = []
    for raw in sites:
        site = raw.strip().lower().rstrip(".")
        if site.startswith("www."):
            site = site[4:]
        labels = site.split(".")
        if (
            not site
            or "://" in site
            or "/" in site
            or ":" in site
            or not re.fullmatch(r"[a-z0-9.-]+", site)
            or any(
                not label or len(label) > 63 or label.startswith("-") or label.endswith("-")
                for label in labels
            )
        ):
            raise ValueError(f"invalid site filter: {raw}")
        normalized.append(site)
    return list(dict.fromkeys(normalized))


def _site_matches(url: str, sites: list[str]) -> bool:
    hostname = (urlsplit(url).hostname or "").lower()
    if hostname.startswith("www."):
        hostname = hostname[4:]
    return any(hostname == site or hostname.endswith(f".{site}") for site in sites)


class DeepSearch:
    """Small, bounded metasearch with auditable fusion and safe text extraction."""

    DEFAULT_BACKENDS = (
        "bing,brave,duckduckgo",
        "google,mojeek,startpage",
        "yandex,yahoo",
    )
    DEFAULT_NEWS_BACKENDS = ("bing,duckduckgo,yahoo",)

    DEFAULT_SEARCH_CONCURRENCY = 6
    DEFAULT_FETCH_CONCURRENCY = 4

    def __init__(
        self,
        *,
        timeout: float = 8,
        max_concurrency: int | None = None,
        max_search_concurrency: int = 6,
        max_fetch_concurrency: int = 4,
        max_download_bytes: int = 2_000_000,
        max_content_chars: int = 50_000,
        github_token: str | None = None,
        backends: tuple[str, ...] | None = None,
        news_backends: tuple[str, ...] | None = None,
    ):
        if timeout <= 0 or max_search_concurrency < 1 or max_fetch_concurrency < 1:
            raise ValueError("timeout and concurrency limits must be positive")
        if max_concurrency is not None:
            max_search_concurrency = max_concurrency
        if max_download_bytes < 1 or max_content_chars < 1:
            raise ValueError("content limits must be positive")
        self.timeout = timeout
        self.max_search_concurrency = max_search_concurrency
        self.max_fetch_concurrency = max_fetch_concurrency
        self.max_download_bytes = max_download_bytes
        self.max_content_chars = max_content_chars
        self.github_token = github_token
        self.backends = backends or self.DEFAULT_BACKENDS
        self.news_backends = news_backends or (
            backends if backends is not None else self.DEFAULT_NEWS_BACKENDS
        )
        self._search_sem: asyncio.Semaphore | None = None
        self._fetch_sem: asyncio.Semaphore | None = None

    def _search_semaphore(self) -> asyncio.Semaphore:
        if self._search_sem is None:
            self._search_sem = asyncio.Semaphore(self.max_search_concurrency)
        return self._search_sem

    def _fetch_semaphore(self) -> asyncio.Semaphore:
        if self._fetch_sem is None:
            self._fetch_sem = asyncio.Semaphore(self.max_fetch_concurrency)
        return self._fetch_sem

    @staticmethod
    def expand(
        query: str,
        sites: list[str] | None = None,
        mode: SearchMode = "plain",
    ) -> list[str]:
        query = query.strip()
        if not query:
            raise ValueError("query must not be empty")
        if mode not in ("plain", "exact", "oss"):
            raise ValueError(f"unsupported search mode: {mode}")
        variants = [query]
        if mode == "exact":
            variants.append(f'"{query}"')
        elif mode == "oss":
            variants.extend((f'"{query}"', f"{query} open source", f"{query} self-hosted"))
        normalized_sites = normalize_sites(sites)
        if normalized_sites:
            variants = [
                f"site:{site} {variant}"
                for site in normalized_sites
                for variant in variants
            ]
        return list(dict.fromkeys(variants))

    async def _ddgs(
        self,
        query: str,
        backend: str,
        limit: int,
        *,
        category: SearchCategory,
        region: str | None,
        safesearch: SafeSearch,
        timelimit: TimeLimit | None,
    ) -> tuple[list[SearchResult], ProviderStatus]:
        async with self._search_semaphore():

            def run() -> tuple[list[SearchResult], ProviderStatus]:
                try:
                    ddgs = DDGS(timeout=self.timeout)
                    method = ddgs.news if category == "news" else ddgs.text
                    kwargs: dict[str, Any] = {
                        "backend": backend,
                        "max_results": limit,
                        "safesearch": safesearch,
                    }
                    if region:
                        kwargs["region"] = region
                    if timelimit:
                        kwargs["timelimit"] = timelimit
                    rows = method(query, **kwargs)
                    results = []
                    for row in rows:
                        result_url = row.get("href") or row.get("url") or ""
                        if result_url and not self._is_ad_redirect(result_url):
                            results.append(
                                SearchResult(
                                    title=row.get("title", ""),
                                    url=result_url,
                                    snippet=row.get("body", ""),
                                    sources=[backend],
                                    published_at=row.get("date"),
                                    publisher=row.get("source"),
                                )
                            )
                    return results, ProviderStatus(backend, query, True, len(results))
                except Exception as exc:
                    return [], ProviderStatus(
                        backend, query, False, error=f"{type(exc).__name__}: {exc}"
                    )

            return await asyncio.to_thread(run)

    async def _search_parts(
        self,
        query: str,
        *,
        sites: list[str] | None,
        mode: SearchMode,
        limit: int,
        category: SearchCategory,
        region: str | None,
        safesearch: SafeSearch,
        timelimit: TimeLimit | None,
    ) -> tuple[list[list[SearchResult]], list[ProviderStatus], list[str]]:
        if not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100")
        if category not in ("text", "news"):
            raise ValueError(f"unsupported search category: {category}")
        if safesearch not in ("on", "moderate", "off"):
            raise ValueError(f"unsupported safe-search mode: {safesearch}")
        if timelimit not in (None, "d", "w", "m", "y"):
            raise ValueError(f"unsupported time limit: {timelimit}")
        normalized_sites = normalize_sites(sites)
        queries = self.expand(query, normalized_sites, mode)
        backends = self.news_backends if category == "news" else self.backends
        batches = await asyncio.gather(
            *(
                self._ddgs(
                    variant,
                    backend,
                    limit,
                    category=category,
                    region=region,
                    safesearch=safesearch,
                    timelimit=timelimit,
                )
                for backend in backends
                for variant in queries
            )
        )
        width = len(queries)
        lists = []
        for index, _backend in enumerate(backends):
            variant_lists = [items for items, _ in batches[index * width : (index + 1) * width]]
            merged = merge_query_variants([items for items in variant_lists if items])
            if merged:
                lists.append(merged)
        return lists, [status for _, status in batches], normalized_sites

    @staticmethod
    def _filter_sites(results: list[SearchResult], sites: list[str]) -> list[SearchResult]:
        if not sites:
            return results
        return [result for result in results if _site_matches(result.url, sites)]

    async def search_run(
        self,
        query: str,
        *,
        sites: list[str] | None = None,
        mode: SearchMode = "plain",
        limit: int = 20,
        fetch: bool = False,
        category: SearchCategory = "text",
        region: str | None = None,
        safesearch: SafeSearch = "moderate",
        timelimit: TimeLimit | None = None,
    ) -> SearchRun:
        lists, providers, normalized_sites = await self._search_parts(
            query,
            sites=sites,
            mode=mode,
            limit=limit,
            category=category,
            region=region,
            safesearch=safesearch,
            timelimit=timelimit,
        )
        results = self._filter_sites(rrf(lists), normalized_sites)[:limit]
        if fetch:
            await self.fetch_content(results)
        return SearchRun(query=query, results=results, providers=providers)

    async def search(self, query: str, **kwargs: Any) -> list[SearchResult]:
        return (await self.search_run(query, **kwargs)).results

    async def fetch_content(self, results: list[SearchResult]) -> None:
        headers = {"User-Agent": "deep-search/0.3 (+https://github.com/Alih-b/super-search)"}
        async with httpx.AsyncClient(
            timeout=self.timeout,
            headers=headers,
            follow_redirects=False,
            trust_env=False,
        ) as client:

            async def one(item: SearchResult) -> None:
                async with self._fetch_semaphore():
                    try:
                        html, final_url = await self._download(client, item.url)
                        content, method = await asyncio.to_thread(self._extract, html, final_url)
                        item.content = content[: self.max_content_chars]
                        item.extraction_method = method
                        item.fetched_url = final_url
                        item.fetched_at = datetime.now(UTC).isoformat()
                    except Exception as exc:
                        item.content = None
                        item.fetch_error = f"{type(exc).__name__}: {exc}"

            await asyncio.gather(*(one(item) for item in results))

    async def _download(self, client: httpx.AsyncClient, url: str) -> tuple[str, str]:
        current = url
        for _ in range(6):
            await self._validate_public_url(current)
            async with client.stream("GET", current) as response:
                if response.is_redirect:
                    location = response.headers.get("location")
                    if not location:
                        raise ValueError("redirect response has no location")
                    current = urljoin(current, location)
                    continue
                response.raise_for_status()
                content_type = response.headers.get("content-type", "").lower()
                if content_type and not any(
                    allowed in content_type
                    for allowed in ("text/html", "application/xhtml+xml", "text/plain")
                ):
                    raise ValueError(f"unsupported content type: {content_type}")
                content_length = response.headers.get("content-length")
                if (
                    content_length
                    and content_length.isdigit()
                    and int(content_length) > self.max_download_bytes
                ):
                    raise ValueError("response exceeds download limit")
                chunks: list[bytes] = []
                size = 0
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if size > self.max_download_bytes:
                        raise ValueError("response exceeds download limit")
                    chunks.append(chunk)
                encoding = response.encoding or "utf-8"
                return b"".join(chunks).decode(encoding, errors="replace"), str(response.url)
        raise ValueError("too many redirects")

    async def _validate_public_url(self, url: str) -> None:
        parsed = urlsplit(url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError("only public HTTP(S) URLs can be fetched")
        if parsed.username or parsed.password:
            raise ValueError("URLs containing credentials are blocked")
        default_port = 443 if parsed.scheme == "https" else 80
        try:
            addresses = await asyncio.wait_for(
                asyncio.to_thread(
                    socket.getaddrinfo,
                    parsed.hostname,
                    parsed.port or default_port,
                    type=socket.SOCK_STREAM,
                ),
                timeout=self.timeout,
            )
        except TimeoutError as exc:
            raise ValueError("hostname resolution timed out") from exc
        except socket.gaierror as exc:
            raise ValueError("hostname could not be resolved") from exc
        for address in addresses:
            ip = ipaddress.ip_address(address[4][0])
            if not ip.is_global:
                raise ValueError("private or reserved network destinations are blocked")

    @staticmethod
    def _is_ad_redirect(url: str) -> bool:
        try:
            parsed = urlsplit(url)
        except ValueError:
            return False
        host = (parsed.hostname or "").lower()
        path = parsed.path.lower()

        def is_domain(domain: str) -> bool:
            return host == domain or host.endswith(f".{domain}")

        return (
            (is_domain("google.com") and path.startswith("/aclick"))
            or (is_domain("bing.com") and path.startswith("/ck/"))
            or is_domain("googleadservices.com")
            or is_domain("doubleclick.net")
        )

    @staticmethod
    def _extract(html: str, url: str) -> tuple[str, str]:
        try:
            import trafilatura

            extracted = trafilatura.extract(html, url=url, include_links=True)
            if extracted and extracted.strip():
                return extracted.strip(), "trafilatura"
        except Exception:
            pass
        without_noise = re.sub(
            r"<(script|style|noscript)\b[^>]*>.*?</\1>",
            " ",
            html,
            flags=re.IGNORECASE | re.DOTALL,
        )
        fallback = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", without_noise)).strip()
        return fallback, "html-text-fallback"

    async def github_run(
        self, query: str, limit: int = 20
    ) -> tuple[list[SearchResult], ProviderStatus]:
        url = "https://api.github.com/search/repositories"
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "deep-search/0.3 (+https://github.com/Alih-b/super-search)",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"
        async with httpx.AsyncClient(
            timeout=self.timeout, headers=headers, trust_env=False
        ) as client:
            try:
                response = await client.get(url, params={"q": query, "per_page": min(limit, 100)})
                response.raise_for_status()
                body = response.json()
                results = [
                    SearchResult(
                        title=item["full_name"],
                        url=item["html_url"],
                        snippet=item.get("description") or "",
                        sources=["github-api"],
                    )
                    for item in body.get("items", [])
                    if isinstance(item, dict) and item.get("full_name") and item.get("html_url")
                ]
                return results, ProviderStatus("github-api", query, True, len(results))
            except Exception as exc:
                return [], ProviderStatus(
                    "github-api", query, False, error=f"{type(exc).__name__}: {exc}"
                )

    async def research_run(
        self,
        query: str,
        *,
        sites: list[str] | None = None,
        mode: SearchMode = "plain",
        limit: int = 20,
        fetch: bool = False,
        include_github: bool = False,
        category: SearchCategory = "text",
        region: str | None = None,
        safesearch: SafeSearch = "moderate",
        timelimit: TimeLimit | None = None,
    ) -> SearchRun:
        web_task = self._search_parts(
            query,
            sites=sites,
            mode=mode,
            limit=limit,
            category=category,
            region=region,
            safesearch=safesearch,
            timelimit=timelimit,
        )
        if include_github:
            (lists, providers, normalized_sites), (github, github_status) = await asyncio.gather(
                web_task, self.github_run(query, limit)
            )
            if github:
                lists.append(github)
            providers.append(github_status)
        else:
            lists, providers, normalized_sites = await web_task
        results = self._filter_sites(rrf(lists), normalized_sites)[:limit]
        if fetch:
            await self.fetch_content(results)
        return SearchRun(query=query, results=results, providers=providers)

    async def research(self, query: str, **kwargs: Any) -> list[SearchResult]:
        return (await self.research_run(query, **kwargs)).results
